import { useEffect, useMemo, useRef, useState } from "react";
import gisEventsCsv from "./data/tashkent-gis-events.csv?raw";
import safeCityLogo from "./assets/safe-city-logo.jpg";

declare global {
  interface Window {
    google: any;
  }
}

let googleMapsLoader: Promise<void> | null = null;

function loadGoogleMaps(key: string) {
  if (window.google?.maps) return Promise.resolve();
  if (googleMapsLoader) return googleMapsLoader;
  googleMapsLoader = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(key)}&v=weekly`;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Google Maps failed to load"));
    document.head.appendChild(script);
  });
  return googleMapsLoader;
}

type IconName =
  | "shield"
  | "home"
  | "stats"
  | "pin"
  | "route"
  | "report"
  | "user"
  | "search"
  | "alert"
  | "trend"
  | "clock"
  | "chevronLeft";

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    shield: <path d="M12 3 5.5 5.7v5.6c0 4.2 2.7 7.9 6.5 9.2 3.8-1.3 6.5-5 6.5-9.2V5.7L12 3Z" />,
    home: <path d="m4 10 8-6 8 6v9H4v-9Zm5 9v-6h6v6" />,
    stats: <path d="M5 19V9m5 10V5m5 14v-7m5 7H3" />,
    pin: <path d="M12 21s6-5.3 6-11a6 6 0 1 0-12 0c0 5.7 6 11 6 11Zm0-8.5A2.5 2.5 0 1 0 12 7a2.5 2.5 0 0 0 0 5.5Z" />,
    route: <path d="M5 19c0-6 4-5 4-9s4-3 7-5m0 0h-3m3 0v3" />,
    report: <path d="M6 3h9l3 3v15H6V3Zm9 0v4h3M9 12h6m-6 4h6" />,
    user: <path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 9c.5-4 3-6 7-6s6.5 2 7 6" />,
    search: <path d="m20 20-4.7-4.7M10.8 18a7.2 7.2 0 1 1 0-14.4 7.2 7.2 0 0 1 0 14.4Z" />,
    alert: <path d="M12 4 3.5 20h17L12 4Zm0 5v5m0 3v.1" />,
    trend: <path d="m4 17 5.2-5.2 3.5 3.5L20 8m0 0h-5m5 0v5" />,
    clock: <path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-13v4l3 2" />,
    chevronLeft: <path d="m15 18-6-6 6-6" />,
  };

  return (
    <svg
      aria-hidden="true"
      fill="none"
      height={size}
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.8"
      viewBox="0 0 24 24"
      width={size}
    >
      {paths[name]}
    </svg>
  );
}

const navItems: { label: string; icon: IconName }[] = [
  { label: "Dashboard", icon: "home" },
  { label: "Statistics", icon: "stats" },
  { label: "Live map", icon: "pin" },
  { label: "Route mapper", icon: "route" },
  { label: "Reports", icon: "report" },
  { label: "Officers", icon: "user" },
];

type DataFilters = {
  region: string;
  type: "All incidents" | "Emergencies" | "Wanted person detections";
  period: "Last hour" | "Last 6 hours" | "Last 24 hours";
};

type AppPage = "Statistics" | "Live map" | "Route mapper";

function Sidebar({ activePage, onNavigate }: { activePage: AppPage; onNavigate: (page: AppPage) => void }) {
  return (
    <aside className="sidebar" id="primary-sidebar">
      <div className="brand">
        <span className="brand-mark"><img alt="Safe City" src={safeCityLogo} /></span>
        <span><strong>Safe City</strong><small>Public safety platform</small></span>
      </div>
      <nav className="nav">
        {navItems.map((item) => (
          <button
            aria-label={item.label}
            className={`nav-item ${item.label === activePage ? "active" : ""}`}
            data-tooltip={item.label}
            key={item.label}
            onClick={() => {
              if (item.label === "Statistics" || item.label === "Live map" || item.label === "Route mapper") onNavigate(item.label);
            }}
          >
            <Icon name={item.icon} size={19} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="control-room">
        <small>Control room</small>
        <strong>+998 [NUMBER]</strong>
      </div>
    </aside>
  );
}

function FilterBar({ filters, onChange, label = "Statistics filters" }: { filters: DataFilters; onChange: (filters: DataFilters) => void; label?: string }) {
  return (
    <section className="panel filters" aria-label={label}>
      <label>
        <span>Region</span>
        <select value={filters.region} onChange={(event) => onChange({ ...filters, region: event.target.value })}>
          <option>All districts</option>
          {["Yunusabad", "Sebzar", "Chilanzar", "Mirzo Ulugbek", "Yashnabad", "Sergeli", "Almazar", "Uchtepa", "Yakkasaray", "Shaykhontohur", "Mirobod", "Bektemir"].map((district) => <option key={district}>{district}</option>)}
        </select>
      </label>
      <label>
        <span>Crime type</span>
        <select value={filters.type} onChange={(event) => onChange({ ...filters, type: event.target.value as DataFilters["type"] })}>
          <option>All incidents</option>
          <option>Emergencies</option>
          <option>Wanted person detections</option>
        </select>
      </label>
      <label>
        <span>Period</span>
        <select value={filters.period} onChange={(event) => onChange({ ...filters, period: event.target.value as DataFilters["period"] })}>
          <option>Last hour</option>
          <option>Last 6 hours</option>
          <option>Last 24 hours</option>
        </select>
      </label>
      <button className="search-button" aria-label="Apply filters"><Icon name="search" size={21} /></button>
    </section>
  );
}

function SummaryCards({ events, filters }: { events: GisEvent[]; filters: DataFilters }) {
  const emergencyCount = events.filter((event) => event.eventType === "Emergency").length;
  const detectionCount = events.length - emergencyCount;
  const leadingType = emergencyCount > detectionCount ? "Emergencies" : "Camera detections";
  const leadingShare = events.length ? Math.round(Math.max(emergencyCount, detectionCount) / events.length * 100) : 0;
  const periodHours = getPeriodHours(filters.period);
  const summaries: { icon: IconName; tone: string; badge: string; badgeTone: string; label: string; value: string; caption: string }[] = [
    { icon: "alert", tone: "blue", badge: `${events.length ? "+" : ""}${Math.round(events.length / Math.max(periodHours, 1))}/hr`, badgeTone: events.length > 20 ? "bad" : "good", label: "Filtered incidents", value: events.length.toLocaleString(), caption: `${filters.region} · ${filters.period.toLowerCase()}` },
    { icon: "trend", tone: "cyan", badge: "AI estimate", badgeTone: "bad", label: "Next-period forecast", value: Math.round(events.length * 1.14).toLocaleString(), caption: "Expected range ±8%" },
    { icon: "shield", tone: "blue", badge: `${leadingShare}%`, badgeTone: "good", label: "Leading signal", value: leadingType, caption: "share of filtered activity" },
    { icon: "clock", tone: "cyan", badge: `${emergencyCount} urgent`, badgeTone: emergencyCount > 8 ? "bad" : "good", label: "Average per hour", value: (events.length / Math.max(periodHours, 1)).toFixed(1), caption: `${detectionCount} camera detections` },
  ];
  return (
    <section className="summary-grid">
      {summaries.map((item) => (
        <article className="panel summary-card" key={item.label}>
          <div className="summary-top">
            <span className={`summary-icon ${item.tone}`}><Icon name={item.icon} size={22} /></span>
            <span className={`badge ${item.badgeTone}`}>{item.badge}</span>
          </div>
          <span className="card-label">{item.label}</span>
          <strong className="summary-value">{item.value}</strong>
          <small className="muted">{item.caption}</small>
        </article>
      ))}
    </section>
  );
}

function TrendChart({ filters }: { filters: DataFilters }) {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const yLabels = [
    ["6,000", 17],
    ["4,500", 75],
    ["3,000", 133],
    ["1,500", 191],
    ["0", 249],
  ] as const;
  return (
    <section className="panel chart-card">
      <header className="panel-header chart-header">
        <div><strong>Crime analysis and forecast</strong><small>{filters.type} · {filters.region} · {filters.period}</small></div>
        <div className="chart-legend">
          <span><i className="legend-dot actual" />Actual data</span>
          <span><i className="legend-dot forecast" />AI forecast (±6% band)</span>
        </div>
      </header>
      <div className="chart-wrap">
        <svg aria-label="Crime analysis line chart" className="trend-chart" viewBox="0 0 900 285">
          <defs>
            <linearGradient id="actualFill" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0" stopColor="#0d8cff" stopOpacity=".25" />
              <stop offset="1" stopColor="#0d8cff" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="forecastBand" x1="0" x2="1">
              <stop offset="0" stopColor="#00d9ed" stopOpacity=".08" />
              <stop offset="1" stopColor="#00d9ed" stopOpacity=".2" />
            </linearGradient>
          </defs>
          {(() => {
            const periodHours = getPeriodHours(filters.period);
            const bucketCount = periodHours === 1 ? 6 : periodHours === 6 ? 6 : 12;
            const bucketMs = periodHours * 60 * 60 * 1000 / bucketCount;
            const periodStart = simulationEnd - periodHours * 60 * 60 * 1000;
            const scopedEvents = filterGisEvents(filters, simulationEnd);
            const values = Array.from({ length: bucketCount }, (_, index) => {
              const start = periodStart + index * bucketMs;
              const end = start + bucketMs;
              return scopedEvents.filter((event) => event.timestamp > start && event.timestamp <= end).length;
            });
            const recentAverage = values.slice(-3).reduce((sum, value) => sum + value, 0) / Math.min(3, values.length);
            const lastValue = values.at(-1) ?? 0;
            const forecast = [
              Math.max(0, Math.round((lastValue + recentAverage) / 2 * 1.06)),
              Math.max(0, Math.round(recentAverage * 1.12)),
              Math.max(0, Math.round(recentAverage * .94)),
            ];
            const maximum = Math.max(4, ...values, ...forecast);
            const chartMaximum = Math.ceil(maximum / 5) * 5;
            const yFor = (value: number) => 249 - value / chartMaximum * 220;
            const actualPoints = values.map((value, index) => ({
              x: 38 + index * (610 / Math.max(1, values.length - 1)),
              y: yFor(value),
            }));
            const forecastPoints = forecast.map((value, index) => ({
              x: 648 + (index + 1) * (242 / forecast.length),
              y: yFor(value),
            }));
            const allForecastPoints = [...actualPoints.slice(-1), ...forecastPoints];
            const smoothPath = (points: { x: number; y: number }[]) => {
              if (points.length < 2) return "";
              const sections = [`M${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)}`];
              for (let index = 1; index < points.length - 1; index += 1) {
                const midpointX = (points[index].x + points[index + 1].x) / 2;
                const midpointY = (points[index].y + points[index + 1].y) / 2;
                sections.push(`Q${points[index].x.toFixed(1)} ${points[index].y.toFixed(1)} ${midpointX.toFixed(1)} ${midpointY.toFixed(1)}`);
              }
              const last = points.at(-1)!;
              sections.push(`T${last.x.toFixed(1)} ${last.y.toFixed(1)}`);
              return sections.join(" ");
            };
            const actualPath = smoothPath(actualPoints);
            const forecastPath = smoothPath(allForecastPoints);
            const bandTop = allForecastPoints.map((point, index) => `${index ? "L" : "M"}${point.x.toFixed(1)} ${yFor(Math.min(chartMaximum, (index ? forecast[index - 1] : lastValue) * 1.08)).toFixed(1)}`).join(" ");
            const bandBottom = [...allForecastPoints].reverse().map((point, reverseIndex) => {
              const sourceIndex = allForecastPoints.length - 1 - reverseIndex;
              const value = sourceIndex ? forecast[sourceIndex - 1] : lastValue;
              return `L${point.x.toFixed(1)} ${yFor(Math.max(0, value * .92)).toFixed(1)}`;
            }).join(" ");
            const timeLabels = values.map((_, index) => {
              const time = new Date(periodStart + (index + 1) * bucketMs);
              return time.toLocaleTimeString("en-GB", { hour: "2-digit", minute: periodHours === 1 ? "2-digit" : undefined, timeZone: "UTC" });
            });
            return (
              <>
                {[1, .75, .5, .25, 0].map((ratio) => {
                  const y = 29 + (1 - ratio) * 220;
                  return <g key={ratio}><text className="axis-label" x="0" y={y + 3}>{Math.round(chartMaximum * ratio)}</text><line className="grid-line" x1="38" x2="890" y1={y} y2={y} /></g>;
                })}
                <path d={`${actualPath} L${actualPoints.at(-1)?.x ?? 38} 249 L38 249Z`} fill="url(#actualFill)" />
                <path className="actual-line" d={actualPath} />
                <path d={`${forecastPath} L890 249 L${actualPoints.at(-1)?.x ?? 648} 249Z`} fill="url(#forecastBand)" />
                <path className="forecast-uncertainty" d={`${bandTop} ${bandBottom} Z`} />
                <path className="forecast-line" d={forecastPath} />
                {actualPoints.map((point, index) => {
                  const tooltipX = Math.max(40, Math.min(810, point.x - 42));
                  const tooltipY = point.y < 65 ? point.y + 14 : point.y - 42;
                  return (
                    <g aria-label={`Recorded: ${values[index]} incidents`} className="chart-point" key={index} tabIndex={0}>
                      <circle className="point-hit" cx={point.x} cy={point.y} r="11" />
                      <g className="point-tooltip">
                        <rect height="29" rx="5" width="84" x={tooltipX} y={tooltipY} />
                        <text x={tooltipX + 42} y={tooltipY + 18}>Recorded: {values[index]}</text>
                      </g>
                    </g>
                  );
                })}
                {forecastPoints.map((point, index) => {
                  const tooltipX = Math.max(40, Math.min(810, point.x - 43));
                  const tooltipY = point.y < 65 ? point.y + 14 : point.y - 42;
                  return (
                    <g aria-label={`Forecast: ${forecast[index]} incidents`} className="chart-point" key={index} tabIndex={0}>
                      <circle className="point-hit" cx={point.x} cy={point.y} r="11" />
                      <g className="point-tooltip">
                        <rect height="29" rx="5" width="86" x={tooltipX} y={tooltipY} />
                        <text x={tooltipX + 43} y={tooltipY + 18}>Forecast: {forecast[index]}</text>
                      </g>
                    </g>
                  );
                })}
                {timeLabels.map((label, index) => <text className="axis-label month" key={`${label}-${index}`} x={actualPoints[index].x} y="274">{label}</text>)}
              </>
            );
          })()}
        </svg>
      </div>
    </section>
  );
}

type DistrictShape = {
  name: string;
  center: { lat: number; lng: number };
  path: { lat: number; lng: number }[];
};

const districtShapes: DistrictShape[] = [
  { name: "Olmazor", center: { lat: 41.355, lng: 69.205 }, path: [{ lat: 41.405, lng: 69.145 }, { lat: 41.405, lng: 69.245 }, { lat: 41.365, lng: 69.265 }, { lat: 41.325, lng: 69.235 }, { lat: 41.322, lng: 69.16 }] },
  { name: "Yunusabad", center: { lat: 41.375, lng: 69.292 }, path: [{ lat: 41.415, lng: 69.245 }, { lat: 41.418, lng: 69.355 }, { lat: 41.37, lng: 69.36 }, { lat: 41.338, lng: 69.315 }, { lat: 41.365, lng: 69.265 }] },
  { name: "Mirzo Ulugbek", center: { lat: 41.345, lng: 69.355 }, path: [{ lat: 41.418, lng: 69.355 }, { lat: 41.39, lng: 69.455 }, { lat: 41.31, lng: 69.445 }, { lat: 41.292, lng: 69.372 }, { lat: 41.338, lng: 69.315 }, { lat: 41.37, lng: 69.36 }] },
  { name: "Uchtepa", center: { lat: 41.295, lng: 69.165 }, path: [{ lat: 41.322, lng: 69.16 }, { lat: 41.325, lng: 69.235 }, { lat: 41.29, lng: 69.225 }, { lat: 41.255, lng: 69.21 }, { lat: 41.248, lng: 69.13 }, { lat: 41.305, lng: 69.115 }] },
  { name: "Shaykhontohur", center: { lat: 41.32, lng: 69.255 }, path: [{ lat: 41.365, lng: 69.265 }, { lat: 41.338, lng: 69.315 }, { lat: 41.302, lng: 69.305 }, { lat: 41.275, lng: 69.27 }, { lat: 41.29, lng: 69.225 }, { lat: 41.325, lng: 69.235 }] },
  { name: "Mirobod", center: { lat: 41.285, lng: 69.294 }, path: [{ lat: 41.302, lng: 69.305 }, { lat: 41.338, lng: 69.315 }, { lat: 41.292, lng: 69.372 }, { lat: 41.255, lng: 69.355 }, { lat: 41.245, lng: 69.305 }, { lat: 41.275, lng: 69.27 }] },
  { name: "Yashnobod", center: { lat: 41.285, lng: 69.38 }, path: [{ lat: 41.292, lng: 69.372 }, { lat: 41.31, lng: 69.445 }, { lat: 41.255, lng: 69.465 }, { lat: 41.218, lng: 69.405 }, { lat: 41.255, lng: 69.355 }] },
  { name: "Chilanzar", center: { lat: 41.265, lng: 69.205 }, path: [{ lat: 41.29, lng: 69.225 }, { lat: 41.275, lng: 69.27 }, { lat: 41.238, lng: 69.26 }, { lat: 41.218, lng: 69.22 }, { lat: 41.205, lng: 69.155 }, { lat: 41.255, lng: 69.21 }] },
  { name: "Yakkasaray", center: { lat: 41.255, lng: 69.275 }, path: [{ lat: 41.275, lng: 69.27 }, { lat: 41.302, lng: 69.305 }, { lat: 41.245, lng: 69.305 }, { lat: 41.218, lng: 69.275 }, { lat: 41.238, lng: 69.26 }] },
  { name: "Sergeli", center: { lat: 41.205, lng: 69.235 }, path: [{ lat: 41.238, lng: 69.26 }, { lat: 41.218, lng: 69.275 }, { lat: 41.19, lng: 69.305 }, { lat: 41.145, lng: 69.28 }, { lat: 41.145, lng: 69.19 }, { lat: 41.205, lng: 69.155 }, { lat: 41.218, lng: 69.22 }] },
  { name: "Yangihayot", center: { lat: 41.185, lng: 69.14 }, path: [{ lat: 41.205, lng: 69.155 }, { lat: 41.145, lng: 69.19 }, { lat: 41.13, lng: 69.09 }, { lat: 41.205, lng: 69.075 }, { lat: 41.248, lng: 69.13 }] },
  { name: "Bektemir", center: { lat: 41.225, lng: 69.43 }, path: [{ lat: 41.255, lng: 69.355 }, { lat: 41.218, lng: 69.405 }, { lat: 41.175, lng: 69.455 }, { lat: 41.135, lng: 69.405 }, { lat: 41.19, lng: 69.305 }, { lat: 41.245, lng: 69.305 }] },
];

type GisEvent = {
  latitude: number;
  longitude: number;
  eventType: "Emergency" | "Wanted_Person_Detection";
  severity: number;
  district: string;
  timestamp: number;
  timestampLabel: string;
};

const gisEvents: GisEvent[] = gisEventsCsv.trim().split("\n").slice(1).map((line) => {
  const [latitude, longitude, eventType, severity, district, timestamp] = line.trim().split(",");
  return {
    latitude: Number(latitude),
    longitude: Number(longitude),
    eventType: eventType as GisEvent["eventType"],
    severity: Number(severity),
    district,
    timestamp: Date.parse(`${timestamp.replace(" ", "T")}Z`),
    timestampLabel: timestamp,
  };
});

const simulationEnd = Math.max(...gisEvents.map((event) => event.timestamp));

type TacticalCluster = {
  x: number;
  y: number;
  type: "detection" | "emergency";
  count: number;
  avgSeverity: number;
  district: string;
  members: GisEvent[];
};

const CLUSTER_PX = 64;

function clusterByPixel(events: GisEvent[], projection: any, type: TacticalCluster["type"]) {
  const projected = events.map((event) => {
    const point = projection.fromLatLngToDivPixel(new window.google.maps.LatLng(event.latitude, event.longitude));
    return { event, x: point.x, y: point.y };
  }).sort((a, b) => b.event.severity - a.event.severity);
  const used = new Array(projected.length).fill(false);
  const clusters: TacticalCluster[] = [];
  projected.forEach((seed, index) => {
    if (used[index]) return;
    const nearby = projected.filter((point, pointIndex) => {
      const matches = !used[pointIndex] && Math.hypot(point.x - seed.x, point.y - seed.y) <= CLUSTER_PX;
      if (matches) used[pointIndex] = true;
      return matches;
    });
    const members = nearby.map((point) => point.event);
    const weight = members.reduce((sum, event) => sum + event.severity, 0);
    const districts = new Map<string, number>();
    members.forEach((event) => districts.set(event.district, (districts.get(event.district) ?? 0) + 1));
    clusters.push({
      x: nearby.reduce((sum, point) => sum + point.x * point.event.severity, 0) / weight,
      y: nearby.reduce((sum, point) => sum + point.y * point.event.severity, 0) / weight,
      type,
      count: members.length,
      avgSeverity: weight / members.length,
      district: [...districts.entries()].sort((a, b) => b[1] - a[1])[0][0],
      members,
    });
  });
  return clusters;
}

function getPeriodHours(period: DataFilters["period"]) {
  return period === "Last hour" ? 1 : period === "Last 6 hours" ? 6 : 24;
}

function filterGisEvents(filters: DataFilters, endTime: number) {
  const startTime = endTime - getPeriodHours(filters.period) * 60 * 60 * 1000;
  return gisEvents.filter((event) => {
    const matchesRegion = filters.region === "All districts" || event.district === filters.region;
    const matchesType = filters.type === "All incidents"
      || (filters.type === "Emergencies" && event.eventType === "Emergency")
      || (filters.type === "Wanted person detections" && event.eventType === "Wanted_Person_Detection");
    return event.timestamp <= endTime && event.timestamp > startTime && matchesRegion && matchesType;
  });
}

function HeatMap({ filters, focusEvent }: { filters: DataFilters; focusEvent?: GisEvent | null }) {
  const [mapStatus, setMapStatus] = useState<"loading" | "ready" | "error">("loading");
  const [showEmergencies, setShowEmergencies] = useState(true);
  const [showDetections, setShowDetections] = useState(true);
  const [showDistricts, setShowDistricts] = useState(true);
  const [mapZoom, setMapZoom] = useState(12);
  const mapElement = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const tacticalOverlay = useRef<any>(null);
  const overlayEvents = useRef<GisEvent[]>([]);
  const overlayLayers = useRef({ emergencies: true, detections: true });
  const polygons = useRef<any[]>([]);
  const markers = useRef<any[]>([]);
  const googleMapsKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined;

  const currentTime = simulationEnd;
  const visibleEvents = useMemo(() => filterGisEvents(filters, currentTime), [currentTime, filters]);
  const lastHourEvents = useMemo(() => visibleEvents.filter((event) => event.timestamp > currentTime - 60 * 60 * 1000), [currentTime, visibleEvents]);
  const activeEmergencies = lastHourEvents.filter((event) => event.eventType === "Emergency");
  const cameraDetections = lastHourEvents.filter((event) => event.eventType === "Wanted_Person_Detection");
  const recentAlerts = useMemo(() => visibleEvents.slice(0, 8), [visibleEvents]);
  overlayEvents.current = visibleEvents;
  overlayLayers.current = { emergencies: showEmergencies, detections: showDetections };

  useEffect(() => {
    if (!googleMapsKey || !mapElement.current) {
      setMapStatus("error");
      return;
    }
    let active = true;
    loadGoogleMaps(googleMapsKey).then(() => {
      if (!active || !mapElement.current) return;
      const map = new window.google.maps.Map(mapElement.current, {
        center: { lat: 41.285, lng: 69.27 },
        zoom: 12,
        minZoom: 10,
        maxZoom: 17,
        tilt: 0,
        heading: 0,
        renderingType: window.google.maps.RenderingType?.VECTOR,
        mapTypeControl: false,
        streetViewControl: false,
        zoomControl: true,
        fullscreenControl: false,
        rotateControl: false,
        styles: [
          { elementType: "geometry", stylers: [{ color: "#212124" }] },
          { elementType: "labels.icon", stylers: [{ visibility: "off" }] },
          { elementType: "labels.text.fill", stylers: [{ color: "#757575" }] },
          { elementType: "labels.text.stroke", stylers: [{ color: "#212124" }] },
          { featureType: "administrative", elementType: "geometry", stylers: [{ color: "#757575" }] },
          { featureType: "administrative.country", elementType: "labels.text.fill", stylers: [{ color: "#9e9e9e" }] },
          { featureType: "administrative.land_parcel", stylers: [{ visibility: "off" }] },
          { featureType: "administrative.locality", elementType: "labels.text.fill", stylers: [{ color: "#bdbdbd" }] },
          { featureType: "poi", stylers: [{ visibility: "off" }] },
          { featureType: "poi.park", elementType: "geometry", stylers: [{ color: "#181818" }] },
          { featureType: "road", elementType: "geometry.fill", stylers: [{ color: "#2c2c2c" }] },
          { featureType: "road", elementType: "labels.text.fill", stylers: [{ color: "#8a8a8a" }] },
          { featureType: "transit", stylers: [{ visibility: "off" }] },
          { featureType: "water", elementType: "geometry", stylers: [{ color: "#000000" }] },
          { featureType: "water", elementType: "labels.text.fill", stylers: [{ color: "#3d3d3d" }] },
        ],
      });
      mapInstance.current = map;
      map.addListener("zoom_changed", () => setMapZoom(map.getZoom() ?? 12));
      polygons.current = districtShapes.map((district) => new window.google.maps.Polygon({
          paths: district.path,
          fillOpacity: 0,
          strokeColor: "#29e6ff",
          strokeOpacity: .92,
          strokeWeight: 1.8,
          map,
        }));
      markers.current = districtShapes.map((district) => new window.google.maps.Marker({
        position: district.center,
        map,
        clickable: false,
        icon: { path: window.google.maps.SymbolPath.CIRCLE, scale: 0 },
        label: { text: district.name, color: "#ffffff", fontSize: "10px", fontWeight: "700" },
      }));

      class TacticalOverlay extends window.google.maps.OverlayView {
        svg: SVGSVGElement | null = null;
        clusters: TacticalCluster[] = [];
        clickHandler: ((event: MouseEvent) => void) | null = null;

        onAdd() {
          this.svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
          this.svg.setAttribute("width", "1");
          this.svg.setAttribute("height", "1");
          this.svg.style.cssText = "position:absolute;left:0;top:0;overflow:visible;pointer-events:none;";
          this.clickHandler = (event: MouseEvent) => {
            const target = (event.target as Element).closest<SVGElement>("[data-cluster-index]");
            if (!target) return;
            const cluster = this.clusters[Number(target.dataset.clusterIndex)];
            if (!cluster) return;
            if (cluster.count === 1) {
              map.panTo({ lat: cluster.members[0].latitude, lng: cluster.members[0].longitude });
              map.setZoom(16);
              return;
            }
            const bounds = new window.google.maps.LatLngBounds();
            cluster.members.forEach((member) => bounds.extend({ lat: member.latitude, lng: member.longitude }));
            map.fitBounds(bounds, 90);
            window.google.maps.event.addListenerOnce(map, "idle", () => {
              if ((map.getZoom() ?? 16) > 16) map.setZoom(16);
            });
          };
          this.svg.addEventListener("click", this.clickHandler);
          this.getPanes().overlayMouseTarget.appendChild(this.svg);
        }

        draw() {
          const projection = this.getProjection();
          if (!projection || !this.svg) return;
          const events = overlayEvents.current;
          this.clusters = [
            ...(overlayLayers.current.emergencies ? clusterByPixel(events.filter((event) => event.eventType === "Emergency"), projection, "emergency") : []),
            ...(overlayLayers.current.detections ? clusterByPixel(events.filter((event) => event.eventType === "Wanted_Person_Detection"), projection, "detection") : []),
          ];
          const showLabels = (map.getZoom() ?? 12) >= 13;
          let output = `<defs>
            <radialGradient id="grad-detection"><stop offset="0%" stop-color="#ef4444" stop-opacity=".03"/><stop offset="70%" stop-color="#ef4444" stop-opacity=".14"/><stop offset="100%" stop-color="#ef4444" stop-opacity=".42"/></radialGradient>
            <radialGradient id="grad-emergency"><stop offset="0%" stop-color="#facc15" stop-opacity=".03"/><stop offset="70%" stop-color="#facc15" stop-opacity=".14"/><stop offset="100%" stop-color="#facc15" stop-opacity=".42"/></radialGradient>
          </defs>`;
          this.clusters.forEach((cluster, index) => {
            const color = cluster.type === "emergency" ? "#facc15" : "#ef4444";
            const { x, y } = cluster;
            if (cluster.count === 1) {
              const size = 3.5 + cluster.avgSeverity * .5;
              output += `<polygon class="tac-cluster" data-cluster-index="${index}" points="${x},${y - size} ${x + size},${y} ${x},${y + size} ${x - size},${y}" fill="${color}" fill-opacity=".6" stroke="${color}" stroke-width="1.2" style="pointer-events:auto"/>`;
              return;
            }
            const radius = 13 + Math.min(17, Math.sqrt(cluster.count) * 5);
            const hot = cluster.avgSeverity / 10 >= .5 || cluster.count >= 10;
            const tier = cluster.avgSeverity >= 7 ? 3 : cluster.avgSeverity >= 4.5 ? 2 : 1;
            const dots = [0, 1, 2].map((dot) => `<circle cx="${x - 7 + dot * 7}" cy="${y - radius - 10}" r="2" fill="${dot < tier ? color : "none"}" stroke="${color}" stroke-width="1"/>`).join("");
            const ticks = [[1, 0], [-1, 0], [0, 1], [0, -1]].map(([dx, dy]) => `<line x1="${x + dx * (radius + 2)}" y1="${y + dy * (radius + 2)}" x2="${x + dx * (radius + 8)}" y2="${y + dy * (radius + 8)}" stroke="${color}" stroke-opacity=".7" stroke-width="1.2"/>`).join("");
            output += `<g class="tac-cluster" data-cluster-index="${index}" style="pointer-events:auto">
              <circle cx="${x}" cy="${y}" r="${radius}" fill="${hot ? `url(#grad-${cluster.type})` : color}" fill-opacity="${hot ? 1 : .05}"/>
              <circle class="tac-ring" cx="${x}" cy="${y}" r="${radius}" fill="none" stroke="${color}" stroke-width="1.5" stroke-opacity=".95"/>
              <circle cx="${x}" cy="${y}" r="${radius + 6}" fill="none" stroke="${color}" stroke-width=".8" stroke-opacity=".3" stroke-dasharray="2 4"><animate attributeName="stroke-opacity" values=".1;.5;.1" dur="3s" repeatCount="indefinite"/></circle>
              ${ticks}${dots}
              <circle cx="${x}" cy="${y}" r="9" fill="rgba(10,14,20,.85)" stroke="${color}" stroke-width="1.2"/>
              <text class="tac-label" x="${x}" y="${y + 3.8}" text-anchor="middle" font-size="11" font-weight="700" fill="${color}">${cluster.count}</text>
              ${showLabels ? `<text class="tac-label" x="${x}" y="${y + radius + 16}" text-anchor="middle" font-size="10" letter-spacing="1" fill="${color}" style="paint-order:stroke;stroke:#0a0e14;stroke-width:3px">${cluster.district.toUpperCase()}</text>` : ""}
            </g>`;
          });
          this.svg.innerHTML = output;
        }

        onRemove() {
          if (this.svg && this.clickHandler) this.svg.removeEventListener("click", this.clickHandler);
          this.svg?.remove();
          this.svg = null;
        }
      }

      tacticalOverlay.current = new TacticalOverlay();
      tacticalOverlay.current.setMap(map);
      map.addListener("zoom_changed", () => tacticalOverlay.current?.draw());
      map.addListener("idle", () => tacticalOverlay.current?.draw());
      setMapStatus("ready");
    }).catch(() => setMapStatus("error"));
    return () => {
      active = false;
      tacticalOverlay.current?.setMap(null);
      polygons.current.forEach((polygon) => polygon.setMap(null));
      markers.current.forEach((marker) => marker.setMap(null));
    };
  }, [googleMapsKey]);

  useEffect(() => {
    tacticalOverlay.current?.draw();
  }, [showDetections, showEmergencies, visibleEvents, mapStatus]);

  useEffect(() => {
    polygons.current.forEach((polygon) => polygon.setVisible(showDistricts));
    markers.current.forEach((marker) => marker.setVisible(showDistricts && mapZoom >= 13));
  }, [showDistricts, mapStatus, mapZoom]);

  useEffect(() => {
    if (!mapInstance.current || filters.region === "All districts") return;
    const aliases: Record<string, string> = { Almazar: "Olmazor", Yashnabad: "Yashnobod", Sebzar: "Shaykhontohur" };
    const shape = districtShapes.find((district) => district.name === (aliases[filters.region] ?? filters.region));
    if (shape) {
      mapInstance.current.panTo(shape.center);
      mapInstance.current.setZoom(13);
    }
  }, [filters.region, mapStatus]);

  useEffect(() => {
    if (!focusEvent || !mapInstance.current || mapStatus !== "ready") return;
    mapInstance.current.panTo({ lat: focusEvent.latitude, lng: focusEvent.longitude });
    mapInstance.current.setZoom(15);
  }, [focusEvent, mapStatus]);

  function locateEvent(event: GisEvent) {
    if (!mapInstance.current) return;
    mapInstance.current.panTo({ lat: event.latitude, lng: event.longitude });
    mapInstance.current.setZoom(15);
  }

  return (
    <section className="panel map-card">
      <header className="panel-header map-header">
        <div><strong>Tashkent real-time GIS</strong><small>{filters.region} · {filters.type} · {filters.period}</small></div>
        <span className="live-status"><i />Live simulation</span>
      </header>
      <div className="map-stage">
        <div className="map-viewport">
          <div className="map-canvas" ref={mapElement} />
          {mapStatus !== "ready" && <div className="map-unavailable">{mapStatus === "loading" ? "Loading Google map and tactical event layers…" : "Google Maps could not load. Enable Maps JavaScript API for this key."}</div>}
          <div className="map-view-label">Surveillance map overview</div>
          <div className="system-status"><i />System online</div>
          <div className="metric-strip">
            <div><span>Active emergencies</span><strong className="emergency-number">{activeEmergencies.length}</strong><small>Last hour</small></div>
            <div><span>Camera detections</span><strong className="camera-number">{cameraDetections.length}</strong><small>Last hour</small></div>
          </div>
          <div className="layer-panel">
            <strong>Intelligence layers</strong>
            <label><input checked={showEmergencies} onChange={(event) => setShowEmergencies(event.target.checked)} type="checkbox" /><i className="layer-swatch emergency" />Emergencies</label>
            <label><input checked={showDetections} onChange={(event) => setShowDetections(event.target.checked)} type="checkbox" /><i className="layer-swatch camera" />Camera detections</label>
            <label><input checked={showDistricts} onChange={(event) => setShowDistricts(event.target.checked)} type="checkbox" /><i className="layer-swatch boundary" />District borders</label>
          </div>
        </div>
        <aside className="alert-feed">
          <header><div><strong>Active alert feed</strong><small>Newest intelligence first</small></div><span>{recentAlerts.length}</span></header>
          <div className="alert-list">
            {recentAlerts.map((event, index) => (
              <article className={`alert-item ${event.eventType === "Emergency" ? "emergency" : "camera"}`} key={`${event.timestamp}-${index}`}>
                <div className="alert-item-top"><i>{event.eventType === "Emergency" ? "!" : "C"}</i><span>{event.timestampLabel.slice(11, 16)}</span></div>
                <strong>{event.eventType === "Emergency" ? "Emergency report" : "Wanted person detected"}</strong>
                <p>{event.district} · Severity {event.severity}</p>
                <button onClick={() => locateEvent(event)}>Locate</button>
              </article>
            ))}
          </div>
        </aside>
      </div>
    </section>
  );
}

const cameraStreams = [
  "https://images.unsplash.com/photo-1453413453658-27fec8f43f29?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=82&w=1200",
  "https://images.unsplash.com/photo-1606152536277-5aa1fd33e150?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=82&w=1200",
  "https://images.unsplash.com/photo-1706875311168-bd3b08547236?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=82&w=1200",
  "https://images.unsplash.com/photo-1590347945111-a14c8efd9249?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=82&w=1200",
];
const tashkentCameras = [
  { id: "CAM-0142", name: "AMIR-TEMUR", district: "Yunusabad", lat: 41.3111, lng: 69.2797, temperature: "8.4°C", humidity: "51% RH", pressure: "1024 hPa" },
  { id: "CAM-0288", name: "CHORSU-CENTER", district: "Shaykhontohur", lat: 41.3262, lng: 69.2351, temperature: "8.1°C", humidity: "54% RH", pressure: "1024 hPa" },
  { id: "CAM-0417", name: "OYBEK-JUNCTION", district: "Mirobod", lat: 41.2987, lng: 69.2724, temperature: "8.6°C", humidity: "50% RH", pressure: "1023 hPa" },
  { id: "CAM-0521", name: "MINOR-RING", district: "Yunusabad", lat: 41.3375, lng: 69.2868, temperature: "7.9°C", humidity: "55% RH", pressure: "1024 hPa" },
  { id: "CAM-0634", name: "CHILANZAR-12", district: "Chilanzar", lat: 41.2752, lng: 69.2031, temperature: "8.3°C", humidity: "52% RH", pressure: "1023 hPa" },
  { id: "CAM-0773", name: "BUYUK-IPAK-YOLI", district: "Mirzo Ulugbek", lat: 41.3268, lng: 69.3338, temperature: "7.8°C", humidity: "56% RH", pressure: "1024 hPa" },
  { id: "CAM-0819", name: "SERGELI-GATE", district: "Sergeli", lat: 41.2246, lng: 69.2194, temperature: "8.7°C", humidity: "49% RH", pressure: "1022 hPa" },
  { id: "CAM-0945", name: "AIRPORT-NORTH", district: "Yakkasaray", lat: 41.2685, lng: 69.2644, temperature: "8.5°C", humidity: "50% RH", pressure: "1023 hPa" },
].map((camera, index) => ({ ...camera, image: cameraStreams[index % cameraStreams.length] }));

function LiveMapPage() {
  const [zuluTime, setZuluTime] = useState("");
  const [cursorCoordinates, setCursorCoordinates] = useState({ lat: 41.2995, lng: 69.2401 });
  const [zoom, setZoom] = useState(12);
  const [viewMode, setViewMode] = useState<"3D" | "2D" | "MAP" | "SAT">("SAT");
  const [dockOpen, setDockOpen] = useState(false);
  const [dockExpanded, setDockExpanded] = useState(false);
  const [analysisActive, setAnalysisActive] = useState(false);
  const [selectedCamera, setSelectedCamera] = useState(tashkentCameras[0]);
  const [showEmergencies, setShowEmergencies] = useState(true);
  const [showDetections, setShowDetections] = useState(true);
  const [showCameras, setShowCameras] = useState(true);
  const mapElement = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markerGroups = useRef<{ emergencies: any[]; detections: any[]; cameras: any[] }>({ emergencies: [], detections: [], cameras: [] });
  const liveTacticalOverlay = useRef<any>(null);
  const liveLayerState = useRef({ emergencies: true, detections: true });
  const liveDistrictPolygons = useRef<any[]>([]);
  const target = { lat: selectedCamera.lat, lng: selectedCamera.lng };
  const googleMapsKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined;
  const liveEvents = useMemo(
    () => filterGisEvents({ region: "All districts", type: "All incidents", period: "Last 24 hours" }, simulationEnd),
    [],
  );
  const emergencyCount = liveEvents.filter((event) => event.eventType === "Emergency").length;
  const detectionCount = liveEvents.length - emergencyCount;
  liveLayerState.current = { emergencies: showEmergencies, detections: showDetections };

  useEffect(() => {
    const updateClock = () => setZuluTime(new Date().toISOString().slice(11, 19) + "Z");
    updateClock();
    const interval = window.setInterval(updateClock, 1000);
    return () => window.clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!googleMapsKey || !mapElement.current) return;
    let active = true;
    const listeners: any[] = [];
    loadGoogleMaps(googleMapsKey).then(() => {
      if (!active || !mapElement.current) return;
      const map = new window.google.maps.Map(mapElement.current, {
        center: { lat: 41.2995, lng: 69.2401 },
        zoom: 12,
        minZoom: 4,
        maxZoom: 20,
        tilt: 0,
        heading: 0,
        mapTypeId: "satellite",
        disableDefaultUI: true,
        gestureHandling: "greedy",
        backgroundColor: "#0b0e14",
      });
      mapInstance.current = map;
      listeners.push(map.addListener("mousemove", (event: any) => {
        if (event.latLng) setCursorCoordinates({ lat: event.latLng.lat(), lng: event.latLng.lng() });
      }));
      listeners.push(map.addListener("zoom_changed", () => setZoom(map.getZoom() ?? 12)));

      liveDistrictPolygons.current = districtShapes.map((district) => new window.google.maps.Polygon({
        paths: district.path,
        fillOpacity: 0,
        strokeColor: "#29e6ff",
        strokeOpacity: .72,
        strokeWeight: 1.4,
        map,
      }));

      class LiveTacticalOverlay extends window.google.maps.OverlayView {
        svg: SVGSVGElement | null = null;
        clusters: TacticalCluster[] = [];
        clickHandler: ((event: MouseEvent) => void) | null = null;

        onAdd() {
          this.svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
          this.svg.setAttribute("width", "1");
          this.svg.setAttribute("height", "1");
          this.svg.style.cssText = "position:absolute;left:0;top:0;overflow:visible;pointer-events:none;";
          this.clickHandler = (event: MouseEvent) => {
            const targetElement = (event.target as Element).closest<SVGElement>("[data-live-cluster]");
            if (!targetElement) return;
            const cluster = this.clusters[Number(targetElement.dataset.liveCluster)];
            if (!cluster) return;
            const bounds = new window.google.maps.LatLngBounds();
            cluster.members.forEach((member) => bounds.extend({ lat: member.latitude, lng: member.longitude }));
            if (cluster.count === 1) {
              map.panTo({ lat: cluster.members[0].latitude, lng: cluster.members[0].longitude });
              map.setZoom(16);
            } else {
              map.fitBounds(bounds, 80);
            }
          };
          this.svg.addEventListener("click", this.clickHandler);
          this.getPanes().overlayMouseTarget.appendChild(this.svg);
        }

        draw() {
          const projection = this.getProjection();
          if (!projection || !this.svg) return;
          this.clusters = [
            ...(liveLayerState.current.emergencies ? clusterByPixel(liveEvents.filter((event) => event.eventType === "Emergency"), projection, "emergency") : []),
            ...(liveLayerState.current.detections ? clusterByPixel(liveEvents.filter((event) => event.eventType === "Wanted_Person_Detection"), projection, "detection") : []),
          ];
          let output = "";
          this.clusters.forEach((cluster, index) => {
            const color = cluster.type === "emergency" ? "#ffc817" : "#ff3b30";
            const { x, y } = cluster;
            if (cluster.count === 1) {
              const size = 4 + cluster.avgSeverity * .4;
              output += `<polygon class="live-tac-cluster" data-live-cluster="${index}" points="${x},${y - size} ${x + size},${y} ${x},${y + size} ${x - size},${y}" fill="${color}" fill-opacity=".7" stroke="${color}" stroke-width="1.3" style="pointer-events:auto"/>`;
              return;
            }
            const radius = 12 + Math.min(15, Math.sqrt(cluster.count) * 4.5);
            const tier = cluster.avgSeverity >= 7 ? 3 : cluster.avgSeverity >= 4.5 ? 2 : 1;
            const dots = [0, 1, 2].map((dot) => `<circle cx="${x - 7 + dot * 7}" cy="${y - radius - 9}" r="2" fill="${dot < tier ? color : "none"}" stroke="${color}" stroke-width="1"/>`).join("");
            const ticks = [[1, 0], [-1, 0], [0, 1], [0, -1]].map(([dx, dy]) => `<line x1="${x + dx * (radius + 2)}" y1="${y + dy * (radius + 2)}" x2="${x + dx * (radius + 7)}" y2="${y + dy * (radius + 7)}" stroke="${color}" stroke-opacity=".75" stroke-width="1"/>`).join("");
            output += `<g class="live-tac-cluster" data-live-cluster="${index}" style="pointer-events:auto">
              <circle cx="${x}" cy="${y}" r="${radius + 6}" fill="${color}" fill-opacity=".035" stroke="${color}" stroke-width=".8" stroke-opacity=".3" stroke-dasharray="2 4"/>
              <circle class="live-tac-ring" cx="${x}" cy="${y}" r="${radius}" fill="${color}" fill-opacity=".07" stroke="${color}" stroke-width="1.5"/>
              ${ticks}${dots}
              <circle cx="${x}" cy="${y}" r="9" fill="rgba(8,11,15,.88)" stroke="${color}" stroke-width="1.2"/>
              <text x="${x}" y="${y + 3.5}" text-anchor="middle" font-family="ui-monospace,monospace" font-size="10" font-weight="800" fill="${color}">${cluster.count}</text>
            </g>`;
          });
          this.svg.innerHTML = output;
        }

        onRemove() {
          if (this.svg && this.clickHandler) this.svg.removeEventListener("click", this.clickHandler);
          this.svg?.remove();
          this.svg = null;
        }
      }

      liveTacticalOverlay.current = new LiveTacticalOverlay();
      liveTacticalOverlay.current.setMap(map);
      listeners.push(map.addListener("zoom_changed", () => liveTacticalOverlay.current?.draw()));
      listeners.push(map.addListener("idle", () => liveTacticalOverlay.current?.draw()));

      const cameraInfoWindow = new window.google.maps.InfoWindow();
      markerGroups.current.cameras = tashkentCameras.map((camera) => {
        const marker = new window.google.maps.Marker({
          position: { lat: camera.lat, lng: camera.lng },
          map,
          title: `${camera.name} · Live camera`,
          zIndex: 20,
          icon: { path: window.google.maps.SymbolPath.CIRCLE, fillColor: "#00ff88", fillOpacity: 1, scale: 7, strokeColor: "#061009", strokeWeight: 2 },
        });
        marker.addListener("click", () => {
          setSelectedCamera(camera);
          setDockOpen(true);
          cameraInfoWindow.close();
          cameraInfoWindow.setContent(`<div class="camera-map-card"><span>● LIVE</span><img src="${camera.image}" alt="${camera.name} camera preview"/><strong>${camera.name}</strong><small>${camera.district.toUpperCase()} · ${camera.id}</small></div>`);
          cameraInfoWindow.open({ anchor: marker, map });
          map.panTo({ lat: camera.lat, lng: camera.lng });
        });
        return marker;
      });
    });
    return () => {
      active = false;
      listeners.forEach((listener) => listener.remove());
      liveTacticalOverlay.current?.setMap(null);
      liveDistrictPolygons.current.forEach((polygon) => polygon.setMap(null));
      Object.values(markerGroups.current).flat().forEach((marker) => marker.setMap(null));
    };
  }, [googleMapsKey]);

  useEffect(() => {
    liveTacticalOverlay.current?.draw();
    markerGroups.current.cameras.forEach((marker) => marker.setVisible(showCameras));
  }, [showEmergencies, showDetections, showCameras]);

  function changeMapView(mode: typeof viewMode) {
    setViewMode(mode);
    if (!mapInstance.current) return;
    if (mode === "MAP") mapInstance.current.setMapTypeId("roadmap");
    if (mode === "SAT" || mode === "2D" || mode === "3D") mapInstance.current.setMapTypeId("satellite");
    mapInstance.current.setTilt(mode === "3D" ? 45 : 0);
  }

  function centerTarget() {
    mapInstance.current?.panTo(target);
    mapInstance.current?.setZoom(15);
  }

  return (
    <section className="osint-console">
      <div className="osint-map" ref={mapElement} />
      <div className="osint-map-shade" />

      <div className="osint-layers">
        <header><strong>Intelligence layers</strong><small>Tashkent · Last 24 hours</small></header>
        <label><input checked={showEmergencies} onChange={(event) => setShowEmergencies(event.target.checked)} type="checkbox" /><i className="osint-swatch emergency" /><span>Emergencies</span><b>{emergencyCount}</b></label>
        <label><input checked={showDetections} onChange={(event) => setShowDetections(event.target.checked)} type="checkbox" /><i className="osint-swatch detection" /><span>Wanted detections</span><b>{detectionCount}</b></label>
        <label><input checked={showCameras} onChange={(event) => setShowCameras(event.target.checked)} type="checkbox" /><i className="osint-swatch camera" /><span>Live cameras</span><b>{tashkentCameras.length}</b></label>
      </div>

      <div className="map-modes" aria-label="Map view">
        {(["3D", "2D", "MAP", "SAT"] as const).map((mode) => (
          <button className={viewMode === mode ? "active" : ""} key={mode} onClick={() => changeMapView(mode)}>{mode}</button>
        ))}
      </div>

      <div className="cursor-telemetry">
        <span>Cursor <b>{cursorCoordinates.lat.toFixed(4)}, {cursorCoordinates.lng.toFixed(4)}</b></span>
        <span>Tashkent, Uzbekistan</span>
        <span>Zoom <b>{zoom.toFixed(1)}</b></span>
      </div>

      <nav className="osint-tool-rail" aria-label="Map tools">
        <button className="active" title="Targeting"><Icon name="pin" size={17} /></button>
        <button title="Signal feeds"><Icon name="trend" size={17} /></button>
        <button title="Analytics"><Icon name="stats" size={17} /></button>
        <button title="Threat alerts"><Icon name="alert" size={17} /></button>
      </nav>

      {dockOpen && (
        <aside className={`inspection-dock ${dockExpanded ? "expanded" : ""}`}>
          <header>
            <span><b>{selectedCamera.id}</b><small>{selectedCamera.lat.toFixed(4)}, {selectedCamera.lng.toFixed(4)}</small></span>
            <time>{zuluTime}</time>
            <em>Secure uplink</em>
            <div>
              <button aria-label="Center map" onClick={centerTarget}>⌖</button>
              <button aria-label="Expand camera dock" onClick={() => setDockExpanded((expanded) => !expanded)}>□</button>
              <button aria-label="Close camera dock" onClick={() => setDockOpen(false)}>×</button>
            </div>
          </header>
          <section className="stream-meta">
            <span className="stream-icon"><Icon name="pin" size={15} /></span>
            <div><strong>{selectedCamera.name}</strong><small>{selectedCamera.district}, Tashkent • Source: Safe City CCTV</small></div>
            <p><b>{selectedCamera.temperature}</b><span>{selectedCamera.humidity}</span><span>{selectedCamera.pressure}</span></p>
          </section>
          <div className="video-shell">
            <img alt={`Live surveillance view from ${selectedCamera.name}`} key={selectedCamera.id} src={selectedCamera.image} />
            <span className="recording-label"><i />Live feed</span>
            <span className="camera-grid" />
            <div className="video-actions">
              <button className={analysisActive ? "active" : ""} onClick={() => setAnalysisActive((active) => !active)}>⚡ {analysisActive ? "Scanning…" : "AI Analyze"}</button>
              <button>◉ Watch 30s</button>
            </div>
          </div>
          <footer>
            <span><small>Feed type</small><b>HLS</b></span>
            <span><small>Status</small><b className="active-status">Active / Recording</b></span>
            <button onClick={centerTarget}>⌖ Map target</button>
          </footer>
        </aside>
      )}

      <footer className="global-ticker">
        <span className="ticker-product">Safe City</span>
        <span>Docs</span><span>Privacy</span>
        <b>$203.33 <i>+3.1%</i></b>
        <div className="ticker-window"><p>M5.0 — 153 km S of Kokopo, Papua New Guinea &nbsp; • &nbsp; M4.9 — 184 km NE of Hihifo, Tonga &nbsp; • &nbsp; M5.2 — 207 km ENE of Misawa, Japan &nbsp; • &nbsp; M4.7 — 109 km E of Petropavlovsk</p></div>
        <strong><i />Online</strong>
      </footer>
    </section>
  );
}

type RouteSearchMode = "identity" | "photo" | "vehicle";
type RoutePoint = (typeof tashkentCameras)[number] & { time: string; confidence: number; clipLength: string };

const routeCameraOrder = [1, 0, 2, 5, 4, 6];
const routeTimes = ["08:42:16", "09:07:51", "09:38:24", "10:16:09", "10:54:37", "11:31:05"];

function RouteEvidenceMap({ active, points, selectedIndex, onSelect }: { active: boolean; points: RoutePoint[]; selectedIndex: number; onSelect: (index: number) => void }) {
  const mapElement = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markers = useRef<any[]>([]);
  const routeLine = useRef<any>(null);
  const googleMapsKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined;

  useEffect(() => {
    if (!googleMapsKey || !mapElement.current) return;
    let mounted = true;
    loadGoogleMaps(googleMapsKey).then(() => {
      if (!mounted || !mapElement.current) return;
      const map = new window.google.maps.Map(mapElement.current, {
        center: { lat: 41.2995, lng: 69.2601 },
        zoom: 12,
        minZoom: 10,
        maxZoom: 18,
        disableDefaultUI: true,
        gestureHandling: "greedy",
        styles: [
          { elementType: "geometry", stylers: [{ color: "#111722" }] },
          { elementType: "labels.text.fill", stylers: [{ color: "#758398" }] },
          { elementType: "labels.text.stroke", stylers: [{ color: "#111722" }] },
          { featureType: "road", elementType: "geometry", stylers: [{ color: "#263143" }] },
          { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#111722" }] },
          { featureType: "water", elementType: "geometry", stylers: [{ color: "#07111c" }] },
          { featureType: "poi", stylers: [{ visibility: "off" }] },
          { featureType: "transit", stylers: [{ visibility: "off" }] },
        ],
      });
      mapInstance.current = map;
      if (!active) return;
      const bounds = new window.google.maps.LatLngBounds();
      points.forEach((point, index) => {
        bounds.extend({ lat: point.lat, lng: point.lng });
        const marker = new window.google.maps.Marker({
          position: { lat: point.lat, lng: point.lng },
          map,
          title: `${index + 1}. ${point.name} · ${point.time}`,
          label: { text: String(index + 1), color: "#06121e", fontSize: "10px", fontWeight: "800" },
          icon: { path: window.google.maps.SymbolPath.CIRCLE, fillColor: "#02d8ed", fillOpacity: 1, scale: 12, strokeColor: "#b9f8ff", strokeWeight: 2 },
          zIndex: 20 + index,
        });
        marker.addListener("click", () => onSelect(index));
        markers.current.push(marker);
      });
      routeLine.current = new window.google.maps.Polyline({
        path: points.map((point) => ({ lat: point.lat, lng: point.lng })),
        map,
        strokeColor: "#118cff",
        strokeOpacity: .95,
        strokeWeight: 4,
        icons: [{ icon: { path: window.google.maps.SymbolPath.FORWARD_CLOSED_ARROW, scale: 3, fillColor: "#02d8ed", fillOpacity: 1, strokeColor: "#02d8ed" }, offset: "50%", repeat: "18%" }],
      });
      map.fitBounds(bounds, 55);
    });
    return () => {
      mounted = false;
      markers.current.forEach((marker) => marker.setMap(null));
      markers.current = [];
      routeLine.current?.setMap(null);
    };
  }, [active, googleMapsKey, onSelect, points]);

  useEffect(() => {
    if (!active || !mapInstance.current || !points[selectedIndex]) return;
    mapInstance.current.panTo({ lat: points[selectedIndex].lat, lng: points[selectedIndex].lng });
  }, [active, points, selectedIndex]);

  return (
    <div className="route-map-wrap">
      <div className="route-map-canvas" ref={mapElement} />
      {!active && <div className="route-map-empty"><Icon name="route" size={28} /><strong>Route visualization waiting</strong><small>Run a search to reconstruct CCTV detections across Tashkent.</small></div>}
      {active && <div className="route-map-status"><i />Route reconstructed · {points.length} verified detections</div>}
    </div>
  );
}

function RouteMapperPage() {
  const [mode, setMode] = useState<RouteSearchMode>("identity");
  const [identityQuery, setIdentityQuery] = useState("");
  const [vehicleQuery, setVehicleQuery] = useState("");
  const [photoName, setPhotoName] = useState("");
  const [photoPreview, setPhotoPreview] = useState("");
  const [fromDate, setFromDate] = useState(new Date(simulationEnd - 24 * 60 * 60 * 1000).toISOString().slice(0, 10));
  const [toDate, setToDate] = useState(new Date(simulationEnd).toISOString().slice(0, 10));
  const [analysisState, setAnalysisState] = useState<"idle" | "analyzing" | "complete">("idle");
  const [selectedDetection, setSelectedDetection] = useState(0);
  const routePoints = useMemo<RoutePoint[]>(() => routeCameraOrder.map((cameraIndex, index) => ({
    ...tashkentCameras[cameraIndex],
    time: routeTimes[index],
    confidence: [98, 96, 94, 91, 89, 87][index],
    clipLength: ["00:18", "00:24", "00:16", "00:31", "00:21", "00:19"][index],
  })), []);
  const searchLabel = mode === "identity"
    ? identityQuery || "Unidentified person"
    : mode === "vehicle"
      ? vehicleQuery || "Unidentified vehicle"
      : photoName || "Uploaded image subject";
  const canAnalyze = mode === "identity" ? identityQuery.trim().length > 1 : mode === "vehicle" ? vehicleQuery.trim().length > 1 : Boolean(photoName);

  function startAnalysis() {
    if (!canAnalyze) return;
    setAnalysisState("analyzing");
    setSelectedDetection(0);
    window.setTimeout(() => setAnalysisState("complete"), 900);
  }

  function selectPhoto(file?: File) {
    if (!file) return;
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    setPhotoName(file.name);
    setPhotoPreview(URL.createObjectURL(file));
    setAnalysisState("idle");
  }

  return (
    <section className="route-workspace">
      <header className="route-page-header">
        <div><span>Investigations / Route reconstruction</span><strong>Subject Route Mapper</strong><small>Correlate CCTV sightings, reconstruct movement, and prepare an evidence report.</small></div>
        <div className="route-system-state"><i />CCTV correlation engine online</div>
      </header>

      <section className="panel route-search-panel">
        <div className="search-mode-tabs" role="tablist" aria-label="Search type">
          <button className={mode === "identity" ? "active" : ""} onClick={() => { setMode("identity"); setAnalysisState("idle"); }}><Icon name="user" size={17} /><span><b>Person identity</b><small>Name or ID card number</small></span></button>
          <button className={mode === "photo" ? "active" : ""} onClick={() => { setMode("photo"); setAnalysisState("idle"); }}><Icon name="search" size={17} /><span><b>Photo matching</b><small>Unknown or foreign subject</small></span></button>
          <button className={mode === "vehicle" ? "active" : ""} onClick={() => { setMode("vehicle"); setAnalysisState("idle"); }}><Icon name="route" size={17} /><span><b>Vehicle search</b><small>Plate or description</small></span></button>
        </div>

        <div className="route-search-form">
          {mode === "identity" && (
            <label className="route-query-field"><span>Full name or ID card number</span><div><Icon name="user" size={18} /><input onChange={(event) => { setIdentityQuery(event.target.value); setAnalysisState("idle"); }} placeholder="e.g. Alisher Karimov or AA 1234567" value={identityQuery} /></div></label>
          )}
          {mode === "vehicle" && (
            <label className="route-query-field"><span>License plate or vehicle description</span><div><Icon name="route" size={18} /><input onChange={(event) => { setVehicleQuery(event.target.value); setAnalysisState("idle"); }} placeholder="e.g. 01 A 777 AA or black Chevrolet Malibu" value={vehicleQuery} /></div></label>
          )}
          {mode === "photo" && (
            <label className={`photo-upload ${photoPreview ? "has-photo" : ""}`}>
              <input accept="image/*" onChange={(event) => selectPhoto(event.target.files?.[0])} type="file" />
              {photoPreview ? <img alt="Uploaded suspect reference" src={photoPreview} /> : <span className="upload-icon"><Icon name="user" size={22} /></span>}
              <span><strong>{photoName || "Upload suspect photograph"}</strong><small>JPG or PNG · Clear frontal image recommended</small></span>
              <b>{photoName ? "Replace" : "Browse"}</b>
            </label>
          )}

          <div className="date-range-fields">
            <label><span>From date</span><input max={toDate} onChange={(event) => { setFromDate(event.target.value); setAnalysisState("idle"); }} type="date" value={fromDate} /></label>
            <i>to</i>
            <label><span>To date</span><input min={fromDate} onChange={(event) => { setToDate(event.target.value); setAnalysisState("idle"); }} type="date" value={toDate} /></label>
          </div>
          <button className="analyze-route-button" disabled={!canAnalyze || analysisState === "analyzing"} onClick={startAnalysis}>
            <Icon name={analysisState === "analyzing" ? "clock" : "search"} size={19} />
            {analysisState === "analyzing" ? "Analyzing CCTV network…" : "Analyze movement"}
          </button>
        </div>
      </section>

      <section className="panel route-map-panel">
        <header className="route-section-header">
          <div><strong>Visual movement route</strong><small>{analysisState === "complete" ? `${searchLabel} · ${fromDate} — ${toDate}` : "CCTV detections will appear here after analysis"}</small></div>
          {analysisState === "complete" && <span>Case RT-{String(simulationEnd).slice(-6)}</span>}
        </header>
        <RouteEvidenceMap active={analysisState === "complete"} onSelect={setSelectedDetection} points={routePoints} selectedIndex={selectedDetection} />
      </section>

      {analysisState === "complete" && (
        <>
          <section className="route-result-summary">
            <article className="panel"><span>Verified detections</span><strong>{routePoints.length}</strong><small>Across {new Set(routePoints.map((point) => point.district)).size} districts</small></article>
            <article className="panel"><span>Analysis confidence</span><strong>92.5%</strong><small>Cross-camera identity match</small></article>
            <article className="panel"><span>Observed duration</span><strong>02h 49m</strong><small>{routePoints[0].time} — {routePoints.at(-1)?.time}</small></article>
            <article className="panel"><span>Evidence clips</span><strong>{routePoints.length}</strong><small>HLS segments preserved</small></article>
          </section>

          <section className="route-evidence-grid">
            <article className="panel detection-timeline">
              <header className="route-section-header"><div><strong>Detection timeline</strong><small>Chronological camera sightings</small></div></header>
              <div className="detection-list">
                {routePoints.map((point, index) => (
                  <button className={selectedDetection === index ? "active" : ""} key={point.id} onClick={() => setSelectedDetection(index)}>
                    <i>{index + 1}</i>
                    <span><strong>{point.name}</strong><small>{point.district} · {point.time}</small></span>
                    <b>{point.confidence}%</b>
                  </button>
                ))}
              </div>
            </article>

            <article className="panel evidence-preview">
              <header className="route-section-header"><div><strong>Video evidence</strong><small>{routePoints[selectedDetection].id} · {routePoints[selectedDetection].time}</small></div><span>Match {routePoints[selectedDetection].confidence}%</span></header>
              <div className="evidence-video">
                <img alt={`CCTV evidence from ${routePoints[selectedDetection].name}`} src={routePoints[selectedDetection].image} />
                <span><i />Recorded</span>
                <b>{routePoints[selectedDetection].clipLength}</b>
                <button>▶ Play evidence clip</button>
              </div>
              <div className="evidence-meta"><span><small>Camera</small><b>{routePoints[selectedDetection].name}</b></span><span><small>Location</small><b>{routePoints[selectedDetection].district}</b></span><span><small>Coordinates</small><b>{routePoints[selectedDetection].lat.toFixed(4)}, {routePoints[selectedDetection].lng.toFixed(4)}</b></span></div>
            </article>
          </section>

          <section className="panel report-panel">
            <div><span className="report-icon"><Icon name="report" size={23} /></span><span><strong>Investigation report ready</strong><small>Includes subject details, mapped route, detection timeline, camera metadata, and video evidence references.</small></span></div>
            <button onClick={() => window.print()}><Icon name="report" size={17} />Print / Save as PDF</button>
          </section>
        </>
      )}
    </section>
  );
}

function RankedList({ title, subtitle, rows }: { title: string; subtitle: string; rows: readonly (readonly [string, string, number, number])[] }) {
  return (
    <section className="panel ranking-card">
      <header className="panel-header"><div><strong>{title}</strong><small>{subtitle}</small></div></header>
      <div className="ranking-list">
        {rows.map(([name, value, width, change], index) => (
          <div className="rank-row" key={name}>
            <span className={`rank-number ${index < 3 ? "top" : ""}`}>{index + 1}</span>
            <div className="rank-content">
              <div className="rank-info"><strong>{name}</strong><span><b>{value}</b><i className={`badge ${change < 0 ? "good" : "bad"}`}>{change > 0 ? "+" : ""}{change}%</i></span></div>
              <div className="progress"><i style={{ width: `${width}%` }} /></div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default function App() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [activePage, setActivePage] = useState<AppPage>("Statistics");
  const [filters, setFilters] = useState<DataFilters>({ region: "All districts", type: "All incidents", period: "Last 24 hours" });
  const filteredEvents = useMemo(() => filterGisEvents(filters, simulationEnd), [filters]);
  const districtCounts = useMemo(() => {
    const counts = new Map<string, number>();
    filteredEvents.forEach((event) => counts.set(event.district, (counts.get(event.district) ?? 0) + 1));
    const sorted = [...counts.entries()].sort((a, b) => b[1] - a[1]);
    const max = sorted[0]?.[1] ?? 1;
    return sorted.map(([name, count], index) => [name, count.toLocaleString(), Math.round(count / max * 100), index % 4 === 0 ? -2 : 3 + index] as const);
  }, [filteredEvents]);
  const typeCounts = useMemo(() => {
    const emergencyCount = filteredEvents.filter((event) => event.eventType === "Emergency").length;
    const detectionCount = filteredEvents.length - emergencyCount;
    const entries = [["Wanted person detections", detectionCount], ["Emergency reports", emergencyCount]].sort((a, b) => Number(b[1]) - Number(a[1])) as [string, number][];
    const max = entries[0]?.[1] ?? 1;
    return entries.map(([name, count], index) => [name, `${count.toLocaleString()} · ${filteredEvents.length ? Math.round(count / filteredEvents.length * 100) : 0}%`, Math.round(count / max * 100), index ? -3 : 6] as const);
  }, [filteredEvents]);

  return (
    <div className={`app-shell ${isSidebarCollapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar activePage={activePage} onNavigate={setActivePage} />
      <button
        aria-controls="primary-sidebar"
        aria-expanded={!isSidebarCollapsed}
        aria-label={isSidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        className="sidebar-toggle"
        onClick={() => setIsSidebarCollapsed((collapsed) => !collapsed)}
        title={isSidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        <Icon name="chevronLeft" size={18} />
      </button>
      <main className="main-content">
        {activePage === "Live map" ? <LiveMapPage /> : activePage === "Route mapper" ? <RouteMapperPage /> : (
          <>
            <FilterBar filters={filters} onChange={setFilters} />
            <SummaryCards events={filteredEvents} filters={filters} />
            <TrendChart filters={filters} />
            <HeatMap filters={filters} />
            <div className="rankings-grid">
              <RankedList title="District activity ranking" subtitle={`${filters.period} · ${filters.type.toLowerCase()}`} rows={districtCounts} />
              <RankedList title="Incident types" subtitle={`${filters.region} · share of filtered incidents`} rows={typeCounts} />
            </div>
          </>
        )}
      </main>
    </div>
  );
}
